---
name: Bug报告
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

---
name: "[Bug Report]BUG反馈"
about: 将你所遇到的BUG反馈给我们
title: "[BUG]"
labels: ''
assignees: ''

---

### 错误描述
> 你所遇到的错误是怎么样的?

### 错误提示和日志内容
> 最好提供错误格式和日志，如果不熟悉编程语言，请提供完整的日志。

### 使用的版本信息
> 提供出现这个问题的程序版本号，或着git hash

### 使用环境
> 是在什么环境下出现的这个问题，Actions，Linux还是windows或者其他
