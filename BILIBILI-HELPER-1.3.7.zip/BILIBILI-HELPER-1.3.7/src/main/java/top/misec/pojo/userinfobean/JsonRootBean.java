package top.misec.pojo.userinfobean;

/**
 * Auto-generated
 *
 * @author Junzhou Liu
 * @create 2020/10/11 4:21
 */

@lombok.Data
public class JsonRootBean {

    private int code;
    private String message;
    private int ttl;
    private Data data;

}