package top.misec.pojo.rewardbean;

import lombok.Data;

@Data
public class RewardData {

    private boolean login;
    private boolean watch;
    private int coins;
    private boolean share;
    private boolean email;
    private boolean tel;
    private boolean safe_question;
    private boolean identify_card;


}