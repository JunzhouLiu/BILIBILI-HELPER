package top.misec.pojo.userinfobean;

import lombok.Data;

/**
 * Auto-generated
 *
 * @author Junzhou Liu
 * @create 2020/10/11 4:21
 */

@Data
public class Pendant {

    private int pid;
    private String name;
    private String image;
    private int expire;
    private String image_enhance;


}