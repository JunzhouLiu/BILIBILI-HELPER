package top.misec.pojo.userinfobean;

import lombok.Data;

/**
 * Auto-generated
 *
 * @author Junzhou Liu
 * @create 2020/10/11 4:21
 */
@Data
public class Vip_label {

    private String path;
    private String text;
    private String label_theme;

}