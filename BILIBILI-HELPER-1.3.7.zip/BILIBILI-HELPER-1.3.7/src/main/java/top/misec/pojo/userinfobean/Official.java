package top.misec.pojo.userinfobean;

import lombok.Data;

/**
 * Auto-generated
 *
 * @author Junzhou Liu
 * @create 2020/10/11 4:21
 */
@Data
public class Official {

    private int role;
    private String title;
    private String desc;
    private int type;

}