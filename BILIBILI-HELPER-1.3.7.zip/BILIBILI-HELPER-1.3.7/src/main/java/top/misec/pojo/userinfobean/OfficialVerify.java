package top.misec.pojo.userinfobean;

import lombok.Data;

/**
 * Auto-generated: 2020-10-11 3:42:3
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
@Data
public class OfficialVerify {

    private int type;
    private String desc;



}